# 👗 Fashion Maven's

### ℹ️ Sobre o projeto:
- Repositório para o projeto final requisitado como menção parcial para a matéria de Programação Web II (PWII);
- Orientadores: Professores João Siles e Najara.

### 👥 Colaboradores:
- Maria Beatriz Fernandes | Full-Stack ([@mb-fernandes](https://github.com/mb-fernandes))
- Melissa Rie | Front-End ([@RieKanzato](https://github.com/RieKanzato))
- Pedro Henrique Passos | Full-Stack ([@pedro-hpm](https://github.com/pedro-hpm))
- Ryan Reis | Banco de Dados ([@Ry2903](https://github.com/Ry2903))
- Sofia Ansanelo | Back-End/Doc ([@SofiAnsanelo](https://github.com/SofiAnsanelo))
